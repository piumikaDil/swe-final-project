package lk.ijse.swe.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import lk.ijse.swe.db.Database;
import lk.ijse.swe.model.Book;
import lk.ijse.swe.model.Room;
import lk.ijse.swe.tm.BookTm;
import lk.ijse.swe.tm.RoomTm;

import java.io.IOException;

public class BookingDetailsFormController {
    public TableView tblDetails;
    public TableColumn colCId;
    public TableColumn colMId;
    public TableColumn colRId;
    public TableColumn colDays;
    public TableColumn colTotal;
    public TableView label;
    public JFXButton btnClose;
    public JFXButton btnBack;

    public void initialize() {
        //setTableData();
        colCId.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        colCId.setCellValueFactory(new PropertyValueFactory<>("mealId"));
        colMId.setCellValueFactory(new PropertyValueFactory<>("roomId"));
        colDays.setCellValueFactory(new PropertyValueFactory<>("days"));
        colTotal.setCellValueFactory(new PropertyValueFactory<>("total"));

    }

        public void setTableData() {
        ObservableList<BookTm> tmList = FXCollections.observableArrayList();
        for (Book o1 : Database.BookingTable
        ) {
            BookTm tm = new BookTm(o1.getCustomerId(),o1.getMealId(),o1.getRoomId(),o1.getDays(),o1.getTotal());

            tmList.add(tm);
        }
        tblDetails.setItems(tmList);

    }

    public void btnCloseOnAction(ActionEvent actionEvent) {
        Stage stage = (Stage) btnClose.getScene().getWindow();
        stage.close();
    }

    public void btnBackIOnAction(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/BookinForm.fxml"))));
        stage.show();
    }
}




